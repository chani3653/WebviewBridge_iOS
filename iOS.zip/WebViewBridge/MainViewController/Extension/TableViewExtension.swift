//
//  TableViewExtension.swift
//  WebViewBridge
//
//  Created by Chan Hwi Park on 3/3/26.
//

import UIKit
extension MainViewController: UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Function List
    
    var functionList: [FunctionItem] {
        let context = BridgeContext(viewController: self, webView: webView)
        return FunctionItem.createFunctionList(context: context)
    }
    
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == functionTableView {
            return functionList.count
        } else if tableView == logTableView {
            return 0 // TODO: 로그 구현
        } else if tableView == storageTableView {
            return 0 // TODO: 스토리지 구현
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == functionTableView {
            guard let cell = tableView.dequeueReusableCell(
                withIdentifier: FunctionTableViewCell.identifier,
                for: indexPath
            ) as? FunctionTableViewCell else {
                return UITableViewCell()
            }
            
            let function = functionList[indexPath.row]
            cell.configure(with: function.name)
            return cell
        }
        
        // TODO: 다른 테이블뷰 구현
        return UITableViewCell()
    }
    
    // MARK: - UITableViewDelegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if tableView == functionTableView {
            let function = functionList[indexPath.row]
            function.action()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}


